﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Program4_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double total = double.Parse(textBox1.Text) * 0.01 +
                               double.Parse(textBox2.Text) * 0.05 +
                               double.Parse(textBox3.Text) * 0.1 +
                               double.Parse(textBox4.Text) * 0.25;
                if (total == 1)
                {
                    label5.Text = "Congratulation! You won.";
                }
                else if (total < 1)
                {
                    label5.Text = "The amount entered was less than a dollar.";
                }
                else
                {
                    label5.Text = "The amount entered was more than a dollar.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
